<?php $__env->startSection('title'); ?>
Register | Funda of web IT
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="class-header">
                    <h3>Edit</h3>
                </div>
                <div class="card-body">
                    <form action="/update/<?php echo e($users->id); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field ('PUT')); ?>

    <div class="form-group">
        <label >Name</label>
        <input type="text" class="form-control" name="username" value="<?php echo e($users->name); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Give role</label>
            <select class="form-control" name="usertype" >
              <option value="admin">Admin</option>
              <option value="vendor">Vendor</option>
              <option value="">None</option>
            </select>
          </div>
          <button type="submit" class="btn btn-success">Update</button>
          <a href="/roleRegister" class="btn btn-danger">Cancel</a>
                    </form>
    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\blog\resources\views/admin/edit.blade.php ENDPATH**/ ?>