<?php $__env->startSection('title'); ?>
home | asif
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add About us</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
         
        </div>
        <form action="/save" method="post">
          <?php echo e(csrf_field()); ?>

        <div class="modal-body">
         
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Name:</label>
              <input type="text" required class="form-control" name="title" minlength="2" id="recipient-name">
            </div>
             <div class="form-group">
              <label for="recipient-name" class="col-form-label">Email:</label>
              <input type="email" required name="subtitle" class="form-control" id="recipient-name">
            </div>
            <div class="form-group">
              <label for="message-text" class="col-form-label">Phone:</label>
              <input type="text" class="form-control" required name="description" id="message-text" minlength="10">
            </div>
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
      </div>
    </div>
  </div>
<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Table</h4>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" >Add</button>
          <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table id="datatable" class="table">
              <thead class=" text-primary">
                <th>
                  Name
                </th>
                <th>
                  Email
                </th>
                <th>
                  Phone
                </th>
                <th >
                  Edit
                </th>
                <th>Delete</th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <?php echo e($a->title); ?>

                  </td>
                  <td>
                    <?php echo e($a->subtitle); ?>

                  </td>
                  <td>
                    <?php echo e($a->description); ?>

                  </td>
               
                  <td> <a href="<?php echo e(url('abouts/'.$a->id)); ?>" class="btn btn-success">Edit</a></td>
                  <td >
                    <form action="/delete2/<?php echo e($a->id); ?>" method="post">
                      <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field ('DELETE')); ?>

                    <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger"> Delete</button>
                    </form>
                   </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready( function () {
    $('#datatable').DataTable();
  
    $('input[name="description"]').keyup(function(e)
                                  {
    if (/\D/g.test(this.value))
    {
     
      this.value = this.value.replace(/\D/g, '');
    }
  });
  } );
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\adminpanel\resources\views/admin/abouts.blade.php ENDPATH**/ ?>