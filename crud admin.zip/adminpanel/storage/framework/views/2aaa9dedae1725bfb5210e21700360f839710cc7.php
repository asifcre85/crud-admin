<?php $__env->startSection('title'); ?>
Abouts Edit | Funda of web IT
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="class-header">
                    <h3>Edit</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('update2/'.$abouts->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field ('PUT')); ?>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Title:</label>
                            <input type="text" class="form-control" name="title" value="<?php echo e($abouts->title); ?>">
                          </div>
                           <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Sub-title:</label>
                            <input type="text" name="subtitle" class="form-control" value="<?php echo e($abouts->subtitle); ?>">
                          </div>
                          <div class="form-group">
                            <label for="message-text" class="col-form-label">Description:</label>
                            <textarea class="form-control" name="description" ><?php echo e($abouts->description); ?></textarea>
                          </div>
          <button type="submit" class="btn btn-success">Update</button>
          <a href="/abouts" class="btn btn-danger">Cancel</a>
                    </form>
    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\blog\resources\views/admin/abouts/edit.blade.php ENDPATH**/ ?>